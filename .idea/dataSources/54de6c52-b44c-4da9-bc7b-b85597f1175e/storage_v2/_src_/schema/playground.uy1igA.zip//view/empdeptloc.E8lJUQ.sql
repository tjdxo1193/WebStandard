create definer = playground@`%` view empdeptloc as
select `d`.`location_id`     AS `location_id`,
       `e`.`department_id`   AS `department_id`,
       `e`.`employee_id`     AS `employee_id`,
       `e`.`first_name`      AS `first_name`,
       `e`.`last_name`       AS `last_name`,
       `e`.`email`           AS `email`,
       `e`.`phone_number`    AS `phone_number`,
       `e`.`hire_date`       AS `hire_date`,
       `e`.`job_id`          AS `job_id`,
       `e`.`salary`          AS `salary`,
       `e`.`commission_pct`  AS `commission_pct`,
       `e`.`manager_id`      AS `manager_id`,
       `d`.`department_name` AS `department_name`,
       `d`.`dmgr_id`         AS `dmgr_id`,
       `l`.`street_address`  AS `street_address`,
       `l`.`postal_code`     AS `postal_code`,
       `l`.`city`            AS `city`,
       `l`.`state_province`  AS `state_province`,
       `l`.`country_id`      AS `country_id`
from ((`playground`.`EMPLOYEES` `e` join `playground`.`departments2` `d` on (`e`.`department_id` = `d`.`department_id`))
         join `playground`.`LOCATIONS` `l` on (`d`.`location_id` = `l`.`location_id`));

