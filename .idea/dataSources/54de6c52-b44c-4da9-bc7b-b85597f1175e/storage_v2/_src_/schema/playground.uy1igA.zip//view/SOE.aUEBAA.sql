create definer = playground@`%` view SOE as
select `o`.`인사번호`     AS `인사번호`,
       `s`.`주문번호`     AS `주문번호`,
       `s`.`운송ID`     AS `운송ID`,
       `s`.`운송이름`     AS `운송이름`,
       `s`.`담당자 전화번호` AS `담당자 전화번호`,
       `o`.`주문일`      AS `주문일`,
       `o`.`납기일`      AS `납기일`,
       `o`.`고객번호`     AS `고객번호`,
       `e`.`주민등록번호`   AS `주민등록번호`,
       `e`.`성명`       AS `성명`,
       `e`.`소속부서`     AS `소속부서`,
       `e`.`직책`       AS `직책`,
       `e`.`입사일`      AS `입사일`
from ((`playground`.`운송` `s` join `playground`.`주문` `o` on (`s`.`주문번호` = `o`.`주문번호`))
         join `playground`.`직원` `e` on (`o`.`인사번호` = `e`.`인사번호`));

