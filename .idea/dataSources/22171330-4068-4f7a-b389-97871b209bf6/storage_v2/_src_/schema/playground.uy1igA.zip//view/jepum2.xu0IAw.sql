create view 제품2 as
select `playground`.`sale_product2`.`prdno`    AS `prdno`,
       `playground`.`sale_product2`.`stock`    AS `stock`,
       `playground`.`sale_product2`.`prdmaker` AS `prdmaker`
from `playground`.`sale_product2`;

