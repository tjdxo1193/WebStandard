create view departments2 as
select `playground`.`DEPARTMENTS`.`department_id`   AS `department_id`,
       `playground`.`DEPARTMENTS`.`department_name` AS `department_name`,
       `playground`.`DEPARTMENTS`.`manager_id`      AS `dmgr_id`,
       `playground`.`DEPARTMENTS`.`location_id`     AS `location_id`
from `playground`.`DEPARTMENTS`;

